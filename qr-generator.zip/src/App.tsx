/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { QRProvider } from './context/QRContext';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { MainLayout } from './components/layout/MainLayout';
import { CustomizationPanel } from './components/qr/CustomizationPanel';
import { QRPreview } from './components/qr/QRPreview';
import { AdminPanel } from './components/admin/AdminPanel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Edit3, List } from 'lucide-react';
import { Toaster } from './components/ui/sonner';

function AppContent() {
  const { t } = useLanguage();

  return (
    <MainLayout>
      <Tabs defaultValue="editor" className="w-full">
        <div className="flex justify-center mb-12">
          <TabsList className="grid w-full max-w-[400px] grid-cols-2 rounded-full p-1 h-12">
            <TabsTrigger value="editor" className="rounded-full gap-2 text-sm font-semibold">
              <Edit3 className="w-4 h-4" />
              {t('editor')}
            </TabsTrigger>
            <TabsTrigger value="admin" className="rounded-full gap-2 text-sm font-semibold">
              <List className="w-4 h-4" />
              {t('myQrs')}
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="editor">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <div className="order-2 lg:order-1">
              <CustomizationPanel />
            </div>
            
            <div className="order-1 lg:order-2 lg:sticky lg:top-24 flex justify-center">
              <QRPreview />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="admin">
          <AdminPanel />
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <AuthProvider>
          <QRProvider>
            <AppContent />
            <Toaster position="top-center" richColors />
          </QRProvider>
        </AuthProvider>
      </ThemeProvider>
    </LanguageProvider>
  );
}


