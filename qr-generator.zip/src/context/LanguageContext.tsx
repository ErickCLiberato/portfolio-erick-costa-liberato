import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'pt' | 'en';

interface Translations {
  [key: string]: {
    [key in Language]: string;
  };
}

export const translations: Translations = {
  editor: { pt: 'Editor', en: 'Editor' },
  myQrs: { pt: 'Meus QRs', en: 'My QRs' },
  profile: { pt: 'Perfil', en: 'Profile' },
  settings: { pt: 'Configurações', en: 'Settings' },
  logout: { pt: 'Sair', en: 'Logout' },
  login: { pt: 'Entrar com Google', en: 'Sign in with Google' },
  darkMode: { pt: 'Modo Escuro', en: 'Dark Mode' },
  lightMode: { pt: 'Modo Claro', en: 'Light Mode' },
  language: { pt: 'Idioma', en: 'Language' },
  saveCloud: { pt: 'Salvar na Nuvem', en: 'Save to Cloud' },
  exportJson: { pt: 'Exportar JSON', en: 'Export JSON' },
  editProfile: { pt: 'Editar Perfil', en: 'Edit Profile' },
  name: { pt: 'Nome', en: 'Name' },
  photoUrl: { pt: 'URL da Foto', en: 'Photo URL' },
  cancel: { pt: 'Cancelar', en: 'Cancel' },
  save: { pt: 'Salvar', en: 'Save' },
  madeBy: { pt: 'Feito por', en: 'Made by' },
  beautifulQr: { pt: 'QR Codes bonitos de forma simples', en: 'Beautiful QR codes made simple' },
  heroDesc: { pt: 'Gere códigos QR estilizados com cores, gradientes e formas personalizadas.', en: 'Generate styled QR codes with custom colors, gradients, and shapes.' },
  load: { pt: 'Carregar', en: 'Load' },
  delete: { pt: 'Excluir', en: 'Delete' },
  confirmDelete: { pt: 'Tem certeza que deseja excluir?', en: 'Are you sure you want to delete?' },
  noConfigs: { pt: 'Você ainda não salvou nenhuma configuração.', en: 'You haven\'t saved any configurations yet.' },
  restricted: { pt: 'Acesso Restrito', en: 'Restricted Access' },
  restrictedDesc: { pt: 'Faça login para gerenciar seus códigos QR.', en: 'Sign in to manage your QR codes.' },
  mainOptions: { pt: 'Opções Principais', en: 'Main Options' },
  dotsOptions: { pt: 'Opções de Pontos', en: 'Dots Options' },
  cornersSquareOptions: { pt: 'Cantos (Quadrado)', en: 'Corners Square Options' },
  cornersDotOptions: { pt: 'Cantos (Ponto)', en: 'Corners Dot Options' },
  backgroundOptions: { pt: 'Plano de Fundo', en: 'Background Options' },
  imageOptions: { pt: 'Opções de Imagem', en: 'Image Options' },
  qrOptions: { pt: 'Opções de QR', en: 'QR Options' },
  data: { pt: 'Conteúdo do QR', en: 'QR Content' },
  linkOrText: { pt: 'Link ou texto', en: 'Link or text' },
  centralLogo: { pt: 'Logo central (opcional)', en: 'Central logo (optional)' },
  qrPreview: { pt: 'Pré-visualização do QR', en: 'QR Preview' },
  previewDesc: { pt: 'Escaneável e atualizado em tempo real', en: 'Scannable and updated in real-time' },
  downloadPng: { pt: 'Baixar PNG', en: 'Download PNG' },
  downloadSvg: { pt: 'Baixar SVG', en: 'Download SVG' },
  generate: { pt: 'Gerar', en: 'Generate' },
  imageFile: { pt: 'Logo', en: 'Logo' },
  clear: { pt: 'Remover', en: 'Remove' },
  width: { pt: 'Largura', en: 'Width' },
  height: { pt: 'Altura', en: 'Height' },
  margin: { pt: 'Margem', en: 'Margin' },
  dotsStyle: { pt: 'Estilo dos Pontos', en: 'Dots style' },
  dotsColor: { pt: 'Cor dos Pontos', en: 'Dots color' },
  cornersSquareStyle: { pt: 'Estilo do Canto', en: 'Corner style' },
  cornersSquareColor: { pt: 'Cor do Canto', en: 'Corner color' },
  cornersDotStyle: { pt: 'Estilo do Ponto Interno', en: 'Inner dot style' },
  cornersDotColor: { pt: 'Cor do Ponto Interno', en: 'Inner dot color' },
  backgroundColor: { pt: 'Cor de Fundo', en: 'Background color' },
  hideBackgroundDots: { pt: 'Ocultar pontos sob o logo', en: 'Hide dots under logo' },
  imageSize: { pt: 'Tamanho do Logo', en: 'Logo size' },
  typeNumber: { pt: 'Tipo', en: 'Type' },
  mode: { pt: 'Modo', en: 'Mode' },
  errorCorrectionLevel: { pt: 'Correção de Erro', en: 'Error Correction' },
  saveConfig: { pt: 'Salvar Configuração', en: 'Save Configuration' },
  configName: { pt: 'Nome da Configuração', en: 'Config Name' },
  saveSuccess: { pt: 'Configuração salva!', en: 'Configuration saved!' },
  saveError: { pt: 'Erro ao salvar.', en: 'Error saving.' },
  loginToSave: { pt: 'Entrar para salvar', en: 'Sign in to save' },
  confirm: { pt: 'Confirmar', en: 'Confirm' },
  saving: { pt: 'Salvando...', en: 'Saving...' },
  loadSuccess: { pt: 'Configuração carregada.', en: 'Configuration loaded.' },
  deleteSuccess: { pt: 'Configuração excluída.', en: 'Configuration deleted.' },
  loadError: { pt: 'Erro ao carregar.', en: 'Error loading.' },
  deleteError: { pt: 'Erro ao excluir.', en: 'Error deleting.' },
  manageCloud: { pt: 'Suas configurações na nuvem.', en: 'Your cloud configurations.' },
  recent: { pt: 'Recente', en: 'Recent' },
  photoTooLarge: { pt: 'Arquivo muito grande (máx. 500KB)', en: 'File too large (max 500KB)' },
  uploadPhoto: { pt: 'Escolher Foto', en: 'Choose Photo' },
  pixel: { pt: 'px', en: 'px' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('language');
      if (saved === 'pt' || saved === 'en') return saved as Language;
      return navigator.language.startsWith('pt') ? 'pt' : 'en';
    }
    return 'pt';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  const t = (key: string) => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
