import React, { useState } from 'react';
import { QrCode, LogIn, LogOut, User as UserIcon, Settings, ChevronDown, Moon, Sun, Camera } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useLanguage } from '../../context/LanguageContext';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../ui/accordion";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { toast } from "sonner";

export function Navbar() {
  const { user, login, logout, updateUserProfile, isLoggingIn } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { t } = useLanguage();
  
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [newName, setNewName] = useState(user?.displayName || '');
  const [newPhoto, setNewPhoto] = useState(user?.photoURL || '');
  const [isUpdating, setIsUpdating] = useState(false);

  const handleUpdateProfile = async () => {
    setIsUpdating(true);
    try {
      await updateUserProfile(newName, newPhoto);
      toast.success(t('profile') + ' ' + t('save'));
      setIsProfileOpen(false);
    } catch (error) {
      toast.error('Erro ao atualizar perfil');
    } finally {
      setIsUpdating(false);
    }
  };

  const openProfileDialog = () => {
    setNewName(user?.displayName || '');
    setNewPhoto(user?.photoURL || '');
    setIsProfileOpen(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500 * 1024) { // 500kb limit
        toast.error(t('photoTooLarge') || 'File too large (max 500KB)');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        setNewPhoto(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <nav className="h-14 bg-card flex items-center justify-between px-6 border-b border-border sticky top-0 z-50">
      <div className="flex items-center gap-2 text-foreground font-semibold">
        <QrCode className="w-5 h-5 text-primary" />
        <span className="text-sm tracking-tight capitalize">QR Generator</span>
      </div>

      <div className="flex items-center gap-4">
        {user ? (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger render={
                <button className="flex items-center gap-2 bg-secondary/50 hover:bg-secondary rounded-full pl-1 pr-3 py-1 transition-colors outline-hidden">
                  <img 
                    src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} 
                    alt={user.displayName || 'User'} 
                    className="w-7 h-7 rounded-full object-cover border border-border"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-xs font-medium text-foreground hidden sm:block">
                    {user.displayName?.split(' ')[0]}
                  </span>
                  <ChevronDown className="w-3 h-3 text-muted-foreground" />
                </button>
              } />
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuGroup>
                  <DropdownMenuLabel className="flex flex-col">
                    <span className="truncate">{user.displayName}</span>
                    <span className="text-[10px] text-muted-foreground truncate font-normal">{user.email}</span>
                  </DropdownMenuLabel>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={openProfileDialog}>
                  <UserIcon className="w-3.5 h-3.5 mr-2" />
                  {t('editProfile')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={toggleTheme}>
                  {theme === 'light' ? (
                    <>
                      <Moon className="w-3.5 h-3.5 mr-2" />
                      {t('darkMode')}
                    </>
                  ) : (
                    <>
                      <Sun className="w-3.5 h-3.5 mr-2" />
                      {t('lightMode')}
                    </>
                  )}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} variant="destructive">
                  <LogOut className="w-3.5 h-3.5 mr-2" />
                  {t('logout')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>{t('editProfile')}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="flex flex-col items-center gap-4 mb-4">
                    <div className="relative group cursor-pointer" onClick={() => document.getElementById('avatar-upload')?.click()}>
                      <img 
                        src={newPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.email}`} 
                        className="w-24 h-24 rounded-full border-2 border-primary object-cover transition-opacity group-hover:opacity-80"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="bg-primary/80 p-2 rounded-full text-white shadow-sm">
                          <Camera className="w-5 h-5" />
                        </div>
                      </div>
                      <input 
                        type="file" 
                        id="avatar-upload" 
                        className="hidden" 
                        accept="image/*"
                        onChange={handleFileChange}
                      />
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 text-xs font-semibold uppercase tracking-wider"
                      onClick={() => document.getElementById('avatar-upload')?.click()}
                    >
                      {t('uploadPhoto')}
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('name')}</Label>
                    <Input 
                      id="name" 
                      value={newName} 
                      onChange={(e) => setNewName(e.target.value)} 
                    />
                  </div>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="advanced" className="border-none">
                      <AccordionTrigger className="py-2 text-xs text-muted-foreground hover:no-underline px-0 border-none">
                        {t('advanced') || 'Advanced Settings'}
                      </AccordionTrigger>
                      <AccordionContent className="px-0">
                        <div className="space-y-2 pt-2">
                          <Label htmlFor="photo" className="text-xs">{t('photoUrl')}</Label>
                          <Input 
                            id="photo" 
                            value={newPhoto} 
                            onChange={(e) => setNewPhoto(e.target.value)} 
                            className="h-8 text-xs"
                          />
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
                <DialogFooter className="gap-2 sm:gap-0">
                  <Button variant="outline" onClick={() => setIsProfileOpen(false)}>{t('cancel')}</Button>
                  <Button onClick={handleUpdateProfile} disabled={isUpdating}>
                    {isUpdating ? '...' : t('save')}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </>
        ) : (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={login}
            disabled={isLoggingIn}
            className="flex items-center gap-2 rounded-full h-9"
          >
            <LogIn className="w-4 h-4" />
            <span>{isLoggingIn ? '...' : t('login')}</span>
          </Button>
        )}
      </div>
    </nav>
  );
}
