import React from 'react';
import { motion } from 'motion/react';
import { useQR } from '../../context/QRContext';
import { useLanguage } from '../../context/LanguageContext';

export function Hero() {
  const { config } = useQR();
  const { t } = useLanguage();
  const qrColor = config.dotsOptions.color;
  const bgColor = config.backgroundOptions.color;

  return (
    <section className="relative overflow-hidden border-b border-border">
      {/* Dynamic Background Gradient */}
      <div 
        className="absolute inset-0 transition-colors duration-700 opacity-10"
        style={{
          background: `linear-gradient(to right, ${qrColor}, ${bgColor})`
        }}
      />
      
      <div className="relative z-10 px-6 py-10 max-w-7xl mx-auto flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <p className="text-xl md:text-2xl font-semibold tracking-tight">
            {t('beautifulQr')}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            {t('heroDesc')}
          </p>
        </motion.div>
      </div>
    </section>
  );
}
