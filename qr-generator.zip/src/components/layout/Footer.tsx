import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { Languages } from 'lucide-react';

export function Footer() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <footer className="h-14 bg-card flex items-center justify-between px-6 border-t border-border mt-auto">
      <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-medium">
        {t('madeBy')}: <span className="text-foreground">Erick Liberato</span>
      </p>
      
      <div className="flex items-center gap-1 bg-secondary/50 p-1 rounded-full">
        <button
          onClick={() => setLanguage('pt')}
          className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all ${
            language === 'pt' 
              ? 'bg-primary text-primary-foreground shadow-sm' 
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          PT
        </button>
        <button
          onClick={() => setLanguage('en')}
          className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all ${
            language === 'en' 
              ? 'bg-primary text-primary-foreground shadow-sm' 
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          EN
        </button>
      </div>
    </footer>
  );
}
