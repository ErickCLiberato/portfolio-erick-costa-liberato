import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useQR } from '../../context/QRContext';
import { useLanguage } from '../../context/LanguageContext';
import { getQRConfigs, deleteQRConfig, QRConfigItem } from '../../services/qrService';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { toast } from 'sonner';
import { Loader2, Trash2, ExternalLink, Calendar, Link as LinkIcon } from 'lucide-react';

export function AdminPanel() {
  const { user } = useAuth();
  const { updateConfig } = useQR();
  const { t } = useLanguage();
  const [configs, setConfigs] = useState<QRConfigItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchConfigs = async () => {
    if (!user) return;
    try {
      const data = await getQRConfigs(user.uid);
      setConfigs(data);
    } catch (error) {
      console.error(error);
      toast.error(t('loadError'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfigs();
  }, [user]);

  const handleDelete = async (configId: string) => {
    if (!user) return;
    if (!window.confirm(t('confirmDelete'))) return;

    try {
      await deleteQRConfig(user.uid, configId);
      setConfigs(configs.filter(c => c.id !== configId));
      toast.success(t('deleteSuccess'));
    } catch (error) {
      console.error(error);
      toast.error(t('deleteError'));
    }
  };

  const handleLoad = (config: QRConfigItem) => {
    updateConfig(config.config);
    toast.success(`${t('loadSuccess')} ("${config.name}")`);
  };

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <h2 className="text-2xl font-bold mb-2">{t('restricted')}</h2>
        <p className="text-muted-foreground mb-6">{t('restrictedDesc')}</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8 px-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{t('myQrs')}</h2>
          <p className="text-muted-foreground">{t('manageCloud')}</p>
        </div>
      </div>

      {configs.length === 0 ? (
        <Card className="border-dashed py-20 text-center">
          <CardContent>
            <p className="text-muted-foreground">{t('noConfigs')}</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {configs.map((item) => (
            <Card key={item.id} className="overflow-hidden group hover:border-primary transition-colors">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg truncate">{item.name}</CardTitle>
                <CardDescription className="flex items-center gap-1.5 truncate">
                  <LinkIcon className="w-3 h-3" />
                  {item.data}
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-4">
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">
                  <Calendar className="w-3 h-3" />
                  {item.createdAt?.toDate ? item.createdAt.toDate().toLocaleDateString() : t('recent')}
                </div>
              </CardContent>
              <CardFooter className="grid grid-cols-2 gap-2 bg-secondary/30 p-4 border-t border-border">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-2"
                  onClick={() => handleLoad(item)}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  {t('load')}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-destructive hover:text-destructive hover:bg-destructive/10 gap-2 border-destructive/20"
                  onClick={() => handleDelete(item.id)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  {t('delete')}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
