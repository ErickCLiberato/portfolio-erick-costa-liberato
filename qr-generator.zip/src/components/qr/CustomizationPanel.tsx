import React, { useState, useRef } from 'react';
import { useQR } from '../../context/QRContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { saveQRConfig } from '../../services/qrService';
import { toast } from 'sonner';
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from '../ui/accordion';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '../ui/select';
import { Slider } from '../ui/slider';
import { Switch } from '../ui/switch';
import { Button } from '../ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogTrigger
} from '../ui/dialog';
import { Download, Cloud, LogIn, Upload, Image as ImageIcon, Type, Square, Maximize2, Move, Settings } from 'lucide-react';
import { QRStyle, QRErrorCorrectionLevel } from '../../types/qr';

export function CustomizationPanel() {
  const { 
    config, 
    updateConfig, 
    updateDotsOptions, 
    updateCornersSquareOptions, 
    updateCornersDotOptions,
    download
  } = useQR();
  const { user, login, isLoggingIn } = useAuth();
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [saveName, setSaveName] = useState('');
  const [isSavedialogOpen, setIsSaveDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast.error(t('photoTooLarge'));
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        updateConfig({ image: event.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    if (!user) {
      toast.error(t('loginToSave'));
      return;
    }
    if (!saveName.trim()) {
      toast.error(t('configName'));
      return;
    }

    setIsSaving(true);
    try {
      await saveQRConfig(user.uid, saveName, config.data, config);
      toast.success(t('saveSuccess'));
      setIsSaveDialogOpen(false);
      setSaveName('');
    } catch (error) {
      console.error(error);
      toast.error(t('saveError'));
    } finally {
      setIsSaving(false);
    }
  };

  const exportAsJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(config, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "qr-config.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Primary Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button 
          variant="default" 
          className="h-12 text-sm font-semibold rounded-xl bg-primary hover:bg-primary/95 shadow-lg shadow-primary/20 transition-all active:scale-95 flex items-center gap-2"
          onClick={() => download('png')}
        >
          <Download className="w-4 h-4" />
          {t('downloadPng')}
        </Button>
        <Button 
          variant="secondary" 
          className="h-12 text-sm font-semibold rounded-xl transition-all active:scale-95 flex items-center gap-2"
          onClick={() => download('svg')}
        >
          <Download className="w-4 h-4" />
          {t('downloadSvg')}
        </Button>
      </div>

      {/* Secondary Actions */}
      <div className="flex gap-2">
        {user ? (
          <Dialog open={isSavedialogOpen} onOpenChange={setIsSaveDialogOpen}>
            <DialogTrigger 
              render={
                <Button variant="outline" className="flex-1 h-9 text-xs gap-1.5 rounded-lg border-border/60 hover:border-primary/50">
                  <Cloud className="w-3.5 h-3.5" />
                  {t('saveCloud')}
                </Button>
              }
            />
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>{t('saveConfig')}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t('configName')}</Label>
                  <Input 
                    id="name" 
                    placeholder="Ex: My QR" 
                    value={saveName}
                    onChange={(e) => setSaveName(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter className="gap-2 sm:gap-0">
                <Button variant="outline" onClick={() => setIsSaveDialogOpen(false)}>{t('cancel')}</Button>
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? t('saving') : t('confirm')}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        ) : (
          <Button 
            className="flex-1 h-9 text-xs gap-1.5 rounded-lg" 
            variant="outline" 
            onClick={login}
            disabled={isLoggingIn}
          >
            <LogIn className="w-3.5 h-3.5 text-muted-foreground" />
            {isLoggingIn ? '...' : t('loginToSave')}
          </Button>
        )}
        <Button 
          variant="outline" 
          className="h-9 w-9 p-0 rounded-lg border-border/60" 
          onClick={exportAsJSON}
          title={t('exportJson')}
        >
          <Type className="w-4 h-4 text-muted-foreground" />
        </Button>
      </div>

      <Accordion type="multiple" defaultValue={['main']} className="w-full space-y-2">
        
        {/* Main Options */}
        <AccordionItem value="main" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-primary" />
              {t('mainOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-5">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('linkOrText')}</Label>
              <Input 
                value={config.data} 
                onChange={(e) => updateConfig({ data: e.target.value })}
                placeholder="https://example.com"
                className="bg-background/50 border-border/40 focus:bg-background"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('centralLogo')}</Label>
              <div className="flex items-center gap-3">
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleImageUpload} 
                  className="hidden" 
                  accept="image/*"
                />
                <Button 
                  variant="outline" 
                  className="w-full h-11 border-dashed border-border/60 hover:border-primary/50 hover:bg-primary/5 gap-2 transition-all group"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-4 h-4 text-muted-foreground transition-transform group-hover:-translate-y-0.5" />
                  <span className="text-sm">{t('uploadPhoto')}</span>
                </Button>
                {config.image && (
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="h-11 w-11 shrink-0 text-destructive hover:bg-destructive/10" 
                    onClick={() => updateConfig({ image: undefined })}
                    title={t('clear')}
                  >
                    <ImageIcon className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-tighter flex items-center gap-1">
                  <Maximize2 className="w-3 h-3" />
                  {t('width')}
                </Label>
                <div className="relative">
                  <Input 
                    type="number" 
                    value={config.width} 
                    onChange={(e) => updateConfig({ width: Number(e.target.value) })} 
                    className="pr-7 bg-background/50 h-9"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground font-mono">{t('pixel')}</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-tighter flex items-center gap-1">
                  <Maximize2 className="w-3 h-3 rotate-90" />
                  {t('height')}
                </Label>
                <div className="relative">
                  <Input 
                    type="number" 
                    value={config.height} 
                    onChange={(e) => updateConfig({ height: Number(e.target.value) })} 
                    className="pr-7 bg-background/50 h-9"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground font-mono">{t('pixel')}</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-tighter flex items-center gap-1">
                  <Move className="w-3 h-3" />
                  {t('margin')}
                </Label>
                <div className="relative">
                  <Input 
                    type="number" 
                    value={config.margin} 
                    onChange={(e) => updateConfig({ margin: Number(e.target.value) })} 
                    className="pr-7 bg-background/50 h-9"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground font-mono">{t('pixel')}</span>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Dots Options */}
        <AccordionItem value="dots" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <Square className="w-4 h-4 text-primary" />
              {t('dotsOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-6">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('dotsStyle')}</Label>
              <Select 
                value={config.dotsOptions.type} 
                onValueChange={(v) => updateDotsOptions({ type: v as QRStyle })}
              >
                <SelectTrigger className="bg-background/50 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="square">Square</SelectItem>
                  <SelectItem value="dots">Dots</SelectItem>
                  <SelectItem value="rounded">Rounded</SelectItem>
                  <SelectItem value="extra-rounded">Extra Rounded</SelectItem>
                  <SelectItem value="classy">Classy</SelectItem>
                  <SelectItem value="classy-rounded">Classy Rounded</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('dotsColor')}</Label>
              <div className="flex gap-4 items-center">
                <Input 
                  type="color" 
                  value={config.dotsOptions.color} 
                  onChange={(e) => updateDotsOptions({ color: e.target.value })}
                  className="w-12 h-12 p-1 rounded-xl cursor-pointer bg-background border-none shadow-sm"
                />
                <Input 
                  type="text" 
                  value={config.dotsOptions.color} 
                  onChange={(e) => updateDotsOptions({ color: e.target.value })}
                  className="font-mono h-10 bg-background/50"
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Corners Square Options */}
        <AccordionItem value="corners-square" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <Maximize2 className="w-4 h-4 text-primary" />
              {t('cornersSquareOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-6">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('cornersSquareStyle')}</Label>
              <Select 
                value={config.cornersSquareOptions.type} 
                onValueChange={(v) => updateCornersSquareOptions({ type: v as any })}
              >
                <SelectTrigger className="bg-background/50 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="square">Square</SelectItem>
                  <SelectItem value="dot">Dot</SelectItem>
                  <SelectItem value="extra-rounded">Extra Rounded</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('cornersSquareColor')}</Label>
              <div className="flex gap-4 items-center">
                <Input 
                  type="color" 
                  value={config.cornersSquareOptions.color} 
                  onChange={(e) => updateCornersSquareOptions({ color: e.target.value })}
                  className="w-12 h-12 p-1 rounded-xl cursor-pointer bg-background border-none shadow-sm"
                />
                <Input 
                  type="text" 
                  value={config.cornersSquareOptions.color} 
                  onChange={(e) => updateCornersSquareOptions({ color: e.target.value })}
                  className="font-mono h-10 bg-background/50"
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Corners Dot Options */}
        <AccordionItem value="corners-dot" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <Move className="w-4 h-4 text-primary" />
              {t('cornersDotOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-6">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('cornersDotStyle')}</Label>
              <Select 
                value={config.cornersDotOptions.type} 
                onValueChange={(v) => updateCornersDotOptions({ type: v as any })}
              >
                <SelectTrigger className="bg-background/50 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="square">Square</SelectItem>
                  <SelectItem value="dot">Dot</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('cornersDotColor')}</Label>
              <div className="flex gap-4 items-center">
                <Input 
                  type="color" 
                  value={config.cornersDotOptions.color} 
                  onChange={(e) => updateCornersDotOptions({ color: e.target.value })}
                  className="w-12 h-12 p-1 rounded-xl cursor-pointer bg-background border-none shadow-sm"
                />
                <Input 
                  type="text" 
                  value={config.cornersDotOptions.color} 
                  onChange={(e) => updateCornersDotOptions({ color: e.target.value })}
                  className="font-mono h-10 bg-background/50"
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Background Options */}
        <AccordionItem value="background" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-primary" />
              {t('backgroundOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-6">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('backgroundColor')}</Label>
              <div className="flex gap-4 items-center">
                <Input 
                  type="color" 
                  value={config.backgroundOptions.color} 
                  onChange={(e) => updateConfig({ backgroundOptions: { color: e.target.value } })}
                  className="w-12 h-12 p-1 rounded-xl cursor-pointer bg-background border-none shadow-sm"
                />
                <Input 
                  type="text" 
                  value={config.backgroundOptions.color} 
                  onChange={(e) => updateConfig({ backgroundOptions: { color: e.target.value } })}
                  className="font-mono h-10 bg-background/50"
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Image Options */}
        <AccordionItem value="image-options" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-primary" />
              {t('imageOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-6">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('hideBackgroundDots')}</Label>
              <Switch 
                checked={config.imageOptions.hideBackgroundDots}
                onCheckedChange={(v) => updateConfig({ 
                  imageOptions: { ...config.imageOptions, hideBackgroundDots: v } 
                })}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('imageSize')}</Label>
                <span className="text-sm text-gray-500">{config.imageOptions.imageSize}</span>
              </div>
              <Slider 
                value={[config.imageOptions.imageSize]} 
                min={0.1} 
                max={1} 
                step={0.1}
                onValueChange={(vals) => updateConfig({ 
                  imageOptions: { ...config.imageOptions, imageSize: vals[0] } 
                })}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('margin')}</Label>
                <span className="text-sm text-gray-500">{config.imageOptions.margin}</span>
              </div>
              <Slider 
                value={[config.imageOptions.margin]} 
                min={0} 
                max={50} 
                step={1}
                onValueChange={(vals) => updateConfig({ 
                  imageOptions: { ...config.imageOptions, margin: vals[0] } 
                })}
              />
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* QR Options */}
        <AccordionItem value="qr-options" className="border-none bg-secondary/20 rounded-xl px-4 overflow-hidden">
          <AccordionTrigger className="text-base font-bold hover:no-underline py-4">
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-primary" />
              {t('qrOptions')}
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 space-y-6">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('typeNumber')}</Label>
              <Input 
                type="number" 
                value={config.qrOptions.typeNumber} 
                onChange={(e) => updateConfig({ 
                  qrOptions: { ...config.qrOptions, typeNumber: Number(e.target.value) } 
                })} 
                className="bg-background/50 h-10"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('mode')}</Label>
              <Select 
                value={config.qrOptions.mode} 
                onValueChange={(v) => updateConfig({ 
                  qrOptions: { ...config.qrOptions, mode: v } 
                })}
              >
                <SelectTrigger className="bg-background/50 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Numeric">Numeric</SelectItem>
                  <SelectItem value="Alphanumeric">Alphanumeric</SelectItem>
                  <SelectItem value="Byte">Byte</SelectItem>
                  <SelectItem value="Kanji">Kanji</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('errorCorrectionLevel')}</Label>
              <Select 
                value={config.qrOptions.errorCorrectionLevel} 
                onValueChange={(v) => updateConfig({ 
                  qrOptions: { ...config.qrOptions, errorCorrectionLevel: v as QRErrorCorrectionLevel } 
                })}
              >
                <SelectTrigger className="bg-background/50 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="L">L (7%)</SelectItem>
                  <SelectItem value="M">M (15%)</SelectItem>
                  <SelectItem value="Q">Q (25%)</SelectItem>
                  <SelectItem value="H">H (30%)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
