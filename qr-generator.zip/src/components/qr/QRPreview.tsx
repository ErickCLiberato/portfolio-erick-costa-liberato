import React, { useEffect, useRef } from 'react';
import QRCodeStyling from 'qr-code-styling';
import { useQR } from '../../context/QRContext';
import { useLanguage } from '../../context/LanguageContext';
import { Sparkles } from 'lucide-react';

export function QRPreview() {
  const { config } = useQR();
  const { t } = useLanguage();
  const qrRef = useRef<HTMLDivElement>(null);
  const qrCode = useRef<QRCodeStyling | null>(null);

  useEffect(() => {
    qrCode.current = new QRCodeStyling(config);
    if (qrRef.current) {
      qrCode.current.append(qrRef.current);
    }
  }, []);

  useEffect(() => {
    if (qrCode.current) {
      qrCode.current.update(config);
    }
  }, [config]);

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="text-center space-y-1">
        <h2 className="text-xl font-bold tracking-tight text-foreground flex items-center justify-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          {t('qrPreview')}
        </h2>
        <p className="text-sm text-muted-foreground font-medium italic">
          {t('previewDesc')}
        </p>
      </div>

      <div className="p-8 bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-border/50 transition-all duration-500 hover:scale-[1.01] hover:shadow-primary/5">
        <div ref={qrRef} className="qr-container bg-white" />
      </div>
    </div>
  );
}
