import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  orderBy,
  updateDoc
} from 'firebase/firestore';
import { db } from './firebase';

export interface QRConfigItem {
  id: string;
  name: string;
  data: string;
  config: any;
  userId: string;
  createdAt: any;
  updatedAt: any;
}

export async function saveQRConfig(userId: string, name: string, data: string, config: any) {
  const colRef = collection(db, 'users', userId, 'qrConfigs');
  return await addDoc(colRef, {
    name,
    data,
    config,
    userId,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
}

export async function updateQRConfig(userId: string, configId: string, updates: Partial<QRConfigItem>) {
  const docRef = doc(db, 'users', userId, 'qrConfigs', configId);
  return await updateDoc(docRef, {
    ...updates,
    updatedAt: serverTimestamp()
  });
}

export async function deleteQRConfig(userId: string, configId: string) {
  const docRef = doc(db, 'users', userId, 'qrConfigs', configId);
  return await deleteDoc(docRef);
}

export async function getQRConfigs(userId: string): Promise<QRConfigItem[]> {
  const colRef = collection(db, 'users', userId, 'qrConfigs');
  const q = query(colRef, orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  } as QRConfigItem));
}
